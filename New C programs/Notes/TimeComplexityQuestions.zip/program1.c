#include <stdio.h>

void foo(int array[], int length)
{
    int sum = 0,i;
    int product = 31;
    for ( i = 0; i < length; i++)
    {
        sum += array[i];
    }

    for ( i = 0; i < length; i++)
    {
        product *= array[i];
    }
}

int main()
{
    int arr[] = {3, 5, 66};
    foo(arr, 3);
    return 0; 
}
